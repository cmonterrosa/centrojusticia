require 'test/unit'

require "rubygems"
require 'active_support'
require 'action_pack'
require 'action_controller'
require 'action_view'
require 'action_controller/test_process'

require(File.expand_path(File.join(File.dirname(__FILE__), '..', 'lib', 'table_builder')))